# Seeding files:

- event_days.json
- opening.json
- activities.json
- tournaments.json
- turns.json
- users.json
- adminstrators.json
- representants.json
- organizers.json
- security.json
